# owe4a_basis

Basisopzet van een Flask applicatie
Dit PyCharm project is te gebruiken als uitgangspunt 
voor een Flask Applicatie.

* requirements.txt bevat de belangrijkste requirements. Door deze op te nemen in de requirements file worden ze automatisch geinstalleerd bij deployment naar Azure.
* bestand met de naam application.py. Hierdoor wordt het in de webapp herkend als de uit te voeren app
  
